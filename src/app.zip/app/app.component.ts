import { Component } from '@angular/core';
import { DaySelected, TimeModels, TimeWorkingModels } from './timeModels';
import { convertTimepickerFormat } from './convertTimePickerfomat';
import { formatTimeStringToObj } from './formatTimeToObj';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Angular Form Validation Tutorial';
  constructor() {}
  headerTable: string[] = [
    'T2',
    'T3',
    'T4',
    'T5',
    'T6',
    'T7',
    'CN',
    'TimeStart',
    'TimeEnd',
    'TimeFrom',
    'TimeTo',
  ];

  timeWorking: any = [
    {
      timeStart: { hour: 12, minute: 14 },
      timeEnd: { hour: 0, minute: 0 },
      timeFrom: { hour: 0, minute: 0 },
      timeTo: { hour: 0, minute: 0 },
    },
    {
      timeStart: { hour: 0, minute: 0 },
      timeEnd: { hour: 0, minute: 0 },
      timeFrom: { hour: 0, minute: 0 },
      timeTo: { hour: 0, minute: 0 },
    },
    {
      timeStart: { hour: 0, minute: 0 },
      timeEnd: { hour: 0, minute: 0 },
      timeFrom: { hour: 0, minute: 0 },
      timeTo: { hour: 0, minute: 0 },
    },
    {
      timeStart: { hour: 0, minute: 0 },
      timeEnd: { hour: 0, minute: 0 },
      timeFrom: { hour: 0, minute: 0 },
      timeTo: { hour: 0, minute: 0 },
    },
    {
      timeStart: { hour: 0, minute: 0 },
      timeEnd: { hour: 0, minute: 0 },
      timeFrom: { hour: 0, minute: 0 },
      timeTo: { hour: 0, minute: 0 },
    },
    {
      timeStart: { hour: 0, minute: 0 },
      timeEnd: { hour: 0, minute: 0 },
      timeFrom: { hour: 0, minute: 0 },
      timeTo: { hour: 0, minute: 0 },
    },
    {
      timeStart: { hour: 0, minute: 0 },
      timeEnd: { hour: 0, minute: 0 },
      timeFrom: { hour: 0, minute: 0 },
      timeTo: { hour: 0, minute: 0 },
    },
  ];

  ValueSelect: string[] = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
  KeySetTime: string[] = ['timeStart', 'timeEnd', 'timeFrom', 'timeTo'];
  daySelected: DaySelected[] = [];
  isChange: boolean = false;

  value1 = {
    T2: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    T3: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    T4: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    T5: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    T6: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    T7: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    CN: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
  };

  value2 = {
    T2: {},
    T3: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    T4: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    T5: {},
    T6: {},
    T7: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
    CN: {
      timeStart: '10:10',
      timeEnd: '10:10',
      timeFrom: '10:10',
      timeTo: '10:10',
    },
  };

  onSelectDate(day: string, indexSelect: number) {
    const checkLineExist = this.daySelected.find(
      (i: DaySelected) => i.row === indexSelect
    );

    const checkExistDayOtherLine = this.daySelected.filter(
      (i: DaySelected) => i.row !== indexSelect && i.daySelect.includes(day)
    );

    // Remove day other line
    if (checkExistDayOtherLine) {
      this.daySelected = this.daySelected.map((i: DaySelected) => {
        if (i.row !== indexSelect && i.daySelect.includes(day)) {
          return {
            ...i,
            daySelect: i.daySelect.filter((i: string) => i !== day),
          };
        } else return i;
      });
    }

    if (!checkLineExist) {
      this.daySelected.push({
        row: indexSelect,
        daySelect: [day],
      });
    } else {
      this.daySelected = this.daySelected.map((i: DaySelected) => {
        if (i.row === indexSelect) {
          return i.daySelect.includes(day)
            ? { ...i, daySelect: i.daySelect.filter((i: string) => i !== day) }
            : { ...i, daySelect: [...i.daySelect, day] };
        } else return i;
      });
    }

    // Remove day empty
    this.daySelected = this.daySelected.filter(
      (i: DaySelected) => i.daySelect.length
    );
  }

  onChecked(day: string, index: number) {
    const checkExist = this.daySelected.find(
      (i: DaySelected) => i.row === index && i.daySelect.includes(day)
    );
    return checkExist ? true : false;
  }

  onCheckDisable(row: number) {
    const hasRow = this.daySelected.find((i: DaySelected) => i.row === row);
    return hasRow ? false : true;
  }

  handleMergeTimeAndDay() {
    const result: any = {};
    this.daySelected.forEach((value: DaySelected) => {
      value.daySelect.forEach((day: string) => {
        result[day] = convertTimepickerFormat(this.timeWorking[value.row]);
      });
    });
  }

  upDate() {
    this.isChange = !this.isChange;
    let result = this.isChange
      ? formatTimeStringToObj(this.value1)
      : formatTimeStringToObj(this.value2);
    this.timeWorking = result.result;
    this.daySelected = result.lstChecked;
  }

  // handleSetTimStartEnd(key: string) {
  //   this.timeWorking = this.timeWorking.map((i: TimeWorkingModels) => {
  //     return {
  //       ...i,
  //       [key]: key === 'timeStart' ? this.timeStart : this.timeEnd,
  //     };
  //   });
  // }
}
